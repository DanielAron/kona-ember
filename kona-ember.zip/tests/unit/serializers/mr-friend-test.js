import {
  moduleFor,
  test
} from 'ember-qunit';

moduleFor('serializer:mr-friend', 'MrFriendSerializer', {
  // Specify the other units that are required for this test.
  // needs: ['serializer:foo']
});

// Replace this with your real tests.
test('it exists', function() {
  var serializer = this.subject();
  ok(serializer);
});
